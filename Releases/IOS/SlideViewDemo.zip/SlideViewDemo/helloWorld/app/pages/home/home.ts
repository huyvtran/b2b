import { Component } from '@angular/core';
import {Page} from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import {NavController, Alert, Platform} from 'ionic-angular';
import { Slides } from 'ionic-angular';

declare var navigator: any;
declare var Connection: any;

@Page({
  templateUrl: 'build/pages/home/home.html'
})
export class HomePage {
  public name;
  credentials: Object = {};
  
  constructor(public alertCtrl: AlertController,private navCtrl: NavController, private platform: Platform){
    this.name = "Andrew";
    this.credentials = {};
  }

   mySlideOptions = {
    initialSlide: 0,
    loop: true,
    pager: true
  };
 


}

