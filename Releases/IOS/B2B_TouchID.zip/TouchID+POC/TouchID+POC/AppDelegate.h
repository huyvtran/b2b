//
//  AppDelegate.h
//  TouchID+POC
//
//  Created by Namrata Rai on 29/09/16.
//  Copyright © 2016 Namrata Rai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RegisterViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) RegisterViewController *regVC;


@end

