//
//  RegisterViewController.m
//  TouchID+POC
//
//  Created by Namrata Rai on 29/09/16.
//  Copyright © 2016 Namrata Rai. All rights reserved.
//

#import "RegisterViewController.h"

@interface RegisterViewController ()

@end

@implementation RegisterViewController
{
    BOOL userSelectTouchID;
}
- (BOOL)canShowDialog
{
    return ![[NSUserDefaults standardUserDefaults] boolForKey:@"isFirstTime"];
}
- (void) setCanShowDialog:(BOOL)firstTime
{
    [[NSUserDefaults standardUserDefaults] setBool:firstTime forKey:@"isFirstTime"];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    if([self canShowDialog])
        [currentUser resetKeychainItem];

     currentUser = [[KeychainItemWrapper alloc] initWithIdentifier:@"YourAppLogin" accessGroup:nil];
     [self initialSetup];
        // Do any additional setup after loading the view from its nib.
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if([self canShowDialog])
    {
        [currentUser resetKeychainItem];
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Enable Touch ID" message:@"Enter your CEC password to setup \nTouch ID for \"Back To Basics\"" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *somethingAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            userSelectTouchID = YES;
        }];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {}];
        [alertController addAction:somethingAction];
        [alertController addAction:cancelAction];
        [self presentViewController:alertController animated:YES completion:^{}];

    }
    else {
        
    }
    [self.navigationController setNavigationBarHidden:YES];
    authController = [AuthController sharedInstance];
    authController.delegate = self;
    if ([_userNameTf.text isEqual:@""])
    {
        
    }
    else
    {
        _touchIDManager = [[TouchIDManager alloc]init];
        _touchIDManager.delegate = self;
        if ([_touchIDManager canEvaluatePolicyMtd])
        {
            LAContext *laContext = [[LAContext alloc] init];
            laContext.localizedFallbackTitle = @"";
            [laContext evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:@"Please scan your fingure print now" reply:^(BOOL authOK, NSError *error) {
                if (authOK) {
                    NSLog(@"ok");
                    [self touchIDSuccessCallBack];
                } else {
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        [self logoutAndResetApplication];
                    });
                }
            }];
//            [_touchIDManager checkAndEvaluateTouchID];
        }
        else
        {
//            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Back To Basics" message:@"Enable touch id" preferredStyle:UIAlertControllerStyleAlert];
//            // Enter your CEC password to setup Touch ID \"Back To Basics\""
//            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
//            [alertController addAction:ok];
//
//            UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:nil];
//            [alertController addAction:cancel];
//
//            [self presentViewController:alertController animated:YES completion:nil];

            
//            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Enable Touch ID" message:@"Enter your CEC password to setup \nTouch ID for \"Back To Basics\"" preferredStyle:UIAlertControllerStyleAlert];
//            
//            CGFloat margin = 8.0F;
////            UILabel *customView = [[UILabel alloc] initWithFrame:CGRectMake(5, 30, alertController.view.bounds.size.width - 115, 100.0F)];
////            UILabel *customView = [[UILabel alloc] initWithFrame:CGRectMake(0, 30, alertController.view.bounds.size.width , 100.0F)];
////
////            customView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin  | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
////
////            
////            NSMutableAttributedString *textToDisplay = [[NSMutableAttributedString alloc] initWithString:@"Enable Touch ID\nEnter your CEC password to setup \nTouch ID for \"Back To Basics\""];
////            [textToDisplay addAttribute:NSFontAttributeName
////                                  value:[UIFont systemFontOfSize:12.0]
////                                  range:NSMakeRange(0, textToDisplay.length-1)];
////
////            [textToDisplay addAttribute:NSFontAttributeName
////                                  value:[UIFont systemFontOfSize:16]
////                                  range:NSMakeRange(0, 15)];
////
////            
////            customView.attributedText = textToDisplay;
////            customView.numberOfLines = 10;
////            customView.textAlignment = NSTextAlignmentCenter;
////            [alertController.view addSubview:customView];
//            
//            UIAlertAction *somethingAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {}];
//            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {}];
//            [alertController addAction:somethingAction];
//            [alertController addAction:cancelAction];
//            [self presentViewController:alertController animated:YES completion:^{}];

            NSLog(@"touch id is not enabled");
        }
        
        
    }
    

    
    
    
}





-(void)touchIDSuccessCallBack
{
    // Once the touch ID is set up is successful, allow user to set up passcode.
  

    if([_userNameTf.text isEqualToString:@"skumar9"] && [_passwordTf.text isEqualToString:@"Aug_2016"]){

        authController._userName = _userNameTf.text;
        authController._passWord = _passwordTf.text;
        
        [authController authenticate];
        
        
        [NSThread detachNewThreadSelector:@selector(waitingForAuthentication:) toTarget:self withObject:nil];
        
        
    }
    else
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert!" message:@"Invalid Username or Password" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
    }

    
    
    
    
}
-(void) showPasscodeAsFallBack
{
    
}

-(void)logoutAndResetApplication
{
    _userNameTf.text=@"";
    _passwordTf.text=@"";
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert!" message:@"Please sign in " preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:ok];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
}

-(void)initialSetup{
    _userNameTf.text = [currentUser objectForKey:CFBridgingRelease(kSecAttrAccount)];
   _userNameTf.textAlignment = NSTextAlignmentLeft;
   _userNameTf.clearButtonMode  = UITextFieldViewModeAlways;
   _userNameTf.autocapitalizationType =UITextAutocapitalizationTypeNone;
    _userNameTf.delegate = self;
    _userNameTf.font = [UIFont fontWithName:@"Helvetica" size:16.0];
    
   _passwordTf.textAlignment = NSTextAlignmentLeft;
      _passwordTf.text = [currentUser objectForKey:CFBridgingRelease(kSecValueData)];
     _passwordTf.clearButtonMode = UITextFieldViewModeAlways;
     _passwordTf.secureTextEntry = YES;
    _passwordTf.delegate = self;
   _passwordTf.font = [UIFont fontWithName:@"Helvetica" size:16.0];
    
 _rememberMeSwitch.on = NO;

    
    spinner = [[UIActivityIndicatorView alloc]
               initWithFrame:CGRectMake(145,400, 30 ,30)];
    [spinner setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleWhite];
    spinner.color = [UIColor whiteColor];
    
    
    [self.view addSubview:spinner];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)login:(id)sender {
    [self.view endEditing:YES];
    if([_userNameTf.text isEqualToString:@"skumar9"] && [_passwordTf.text isEqualToString:@"Aug_2016"]){
//        _rememberMeSwitch.on? [currentUser setObject:_userNameTf.text forKey:CFBridgingRelease(kSecAttrAccount)]: [currentUser resetKeychainItem];
//        _rememberMeSwitch.on? [currentUser setObject:_passwordTf.text forKey:CFBridgingRelease(kSecValueData)]: [currentUser resetKeychainItem];
        if(userSelectTouchID)
            [self setCanShowDialog:YES];

        [self canShowDialog]==NO? [currentUser setObject:_userNameTf.text forKey:CFBridgingRelease(kSecAttrAccount)]: [currentUser resetKeychainItem];
        [self canShowDialog] == NO? [currentUser setObject:_passwordTf.text forKey:CFBridgingRelease(kSecValueData)]: [currentUser
                                                                                                                 resetKeychainItem];
        //    if (userNameFeild.text.length>0 && passWordFeild.text.length >0)
        //    {
        authController._userName = _userNameTf.text;
        authController._passWord = _passwordTf.text;
        
        [authController authenticate];

        
        [NSThread detachNewThreadSelector:@selector(waitingForAuthentication:) toTarget:self withObject:nil];

        
    }
    else
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert!" message:@"Invalid Username or Password" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];

    }
    
   
}
- (void)waitingForAuthentication:(id)sender
{
//    [spinner startAnimating];
    
   _signInVC = [[SignInViewController alloc] initWithNibName:@"SignInViewController" bundle:nil];
    [self.navigationController pushViewController:_signInVC animated:YES];
//    [_signInButton setTitle:@"Login Succes" forState:UIControlStateNormal];
    
}
@end
