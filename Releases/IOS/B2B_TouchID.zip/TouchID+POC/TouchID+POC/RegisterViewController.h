//
//  RegisterViewController.h
//  TouchID+POC
//
//  Created by Namrata Rai on 29/09/16.
//  Copyright © 2016 Namrata Rai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AuthController.h"
#import "KeychainItemWrapper.h"
#import "PasscodeManager.h"
#import "TouchIDManager.h"
#import "SignInViewController.h"

@interface RegisterViewController : UIViewController<TouchIDSetUpDelegate,TouchIDValidaterDelegate,UITextFieldDelegate,UIAlertViewDelegate>
{
    KeychainItemWrapper *currentUser;
    AuthController* authController;
     UIActivityIndicatorView *spinner;
}
@property (weak, nonatomic) IBOutlet UITextField *userNameTf;
@property (weak, nonatomic) IBOutlet UITextField *passwordTf;
@property (weak, nonatomic) IBOutlet UISwitch *rememberMeSwitch;
@property (weak, nonatomic) IBOutlet UIButton *signInButton;
@property (nonatomic,retain) TouchIDManager *touchIDManager;
@property (strong, nonatomic) SignInViewController *signInVC;

- (IBAction)login:(id)sender;

@end
