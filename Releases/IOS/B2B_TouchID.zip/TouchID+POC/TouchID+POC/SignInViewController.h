//
//  SignInViewController.h
//  TouchID+POC
//
//  Created by Namrata Rai on 29/09/16.
//  Copyright © 2016 Namrata Rai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignInViewController : UIViewController

@end
